---
name: Atmospheric Minimalist
colors:
  surface: '#10141a'
  surface-dim: '#10141a'
  surface-bright: '#353940'
  surface-container-lowest: '#0a0e14'
  surface-container-low: '#181c22'
  surface-container: '#1c2026'
  surface-container-high: '#262a31'
  surface-container-highest: '#31353c'
  on-surface: '#dfe2eb'
  on-surface-variant: '#ccc6bb'
  inverse-surface: '#dfe2eb'
  inverse-on-surface: '#2d3137'
  outline: '#959087'
  outline-variant: '#4a463f'
  surface-tint: '#cdc6b7'
  primary: '#ffffff'
  on-primary: '#343026'
  primary-container: '#e9e2d3'
  on-primary-container: '#696458'
  inverse-primary: '#635e52'
  secondary: '#bfc7d1'
  on-secondary: '#293139'
  secondary-container: '#424a52'
  on-secondary-container: '#b1b9c3'
  tertiary: '#ffffff'
  on-tertiary: '#253239'
  tertiary-container: '#d6e5ed'
  on-tertiary-container: '#59666e'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e9e2d3'
  primary-fixed-dim: '#cdc6b7'
  on-primary-fixed: '#1e1b12'
  on-primary-fixed-variant: '#4b463c'
  secondary-fixed: '#dbe3ed'
  secondary-fixed-dim: '#bfc7d1'
  on-secondary-fixed: '#141c23'
  on-secondary-fixed-variant: '#40484f'
  tertiary-fixed: '#d6e5ed'
  tertiary-fixed-dim: '#bac9d1'
  on-tertiary-fixed: '#101d24'
  on-tertiary-fixed-variant: '#3b4950'
  background: '#10141a'
  on-background: '#dfe2eb'
  surface-variant: '#31353c'
typography:
  display-lg:
    fontFamily: EB Garamond
    fontSize: 120px
    fontWeight: '400'
    lineHeight: 110%
    letterSpacing: -0.02em
  headline-xl:
    fontFamily: EB Garamond
    fontSize: 80px
    fontWeight: '400'
    lineHeight: 110%
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: EB Garamond
    fontSize: 48px
    fontWeight: '400'
    lineHeight: 120%
  headline-lg-mobile:
    fontFamily: EB Garamond
    fontSize: 36px
    fontWeight: '400'
    lineHeight: 120%
  title-md:
    fontFamily: Hanken Grotesk
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 150%
    letterSpacing: 0.1em
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 160%
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 160%
  label-sm:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 100%
    letterSpacing: 0.05em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  container-max: 1440px
  edge-margin-desktop: 80px
  edge-margin-mobile: 24px
  gutter: 32px
  section-gap: 160px
  element-gap: 24px
---

## Brand & Style
The design system is centered on a cinematic and editorial aesthetic that balances a sense of vastness with intimate detail. It targets a high-end creative audience, evoking an emotional response of serenity, intentionality, and quiet confidence.

The visual style is a blend of **Minimalism** and **Atmospheric Editorial**. It utilizes heavy whitespace (or "empty air"), expansive background imagery, and high-contrast typography. The interface should feel like a digital gallery—functional but subservient to the content and photography. Interaction should be fluid and soft, avoiding jarring transitions in favor of subtle fades and smooth parallax effects.

## Colors
The palette is derived from the natural transition of a coastal horizon. 

- **Primary (Sand):** Used for primary actions, main heading highlights, and high-contrast text against dark backgrounds. It provides warmth and a tactile, paper-like quality.
- **Secondary (Deep Ocean):** A muted, dark blue-grey used for secondary buttons and container backgrounds.
- **Tertiary (Misty Slate):** A desaturated mid-tone for borders, icons, and secondary labels to maintain low visual noise.
- **Neutral (Midnight):** The core canvas color, ensuring the atmospheric background images remain the focal point.

The default mode is **Dark**, as it enhances the depth of photography and provides a more immersive, cinematic experience.

## Typography
The typography relies on a sophisticated tension between the classical elegance of **EB Garamond** (italicized for maximum atmospheric effect) and the clinical precision of **Hanken Grotesk**.

- **Headlines:** Use EB Garamond in regular or italic styles. Italicization should be used for primary "All About Me" style headers to create a poetic, editorial feel.
- **UI Elements & Body:** Hanken Grotesk provides a modern, neutral contrast. Use wide letter-spacing for navigation and labels to evoke a premium, spaced-out feel.
- **Scale:** Large display sizes are encouraged for impact, but must scale down aggressively for mobile to maintain legibility.

## Layout & Spacing
The layout follows a **Fluid Grid** model with generous margins to create a sense of luxury and focus.

- **Grid:** A 12-column grid for desktop, reducing to 4 columns for mobile.
- **Rhythm:** Spacing is oversized. Use `section-gap` between major narrative blocks to allow the eye to rest.
- **Alignment:** Centralize primary hero content. Use asymmetrical placements for secondary content (e.g., text shifted to columns 7-11) to mimic high-end magazine layouts.
- **Safe Areas:** Ensure a minimum of 80px horizontal padding on desktop to keep content from feeling "trapped" by the screen edges.

## Elevation & Depth
Depth is created through **Backdrop Blurs** and **Tonal Layers** rather than traditional shadows.

- **Surfaces:** Use semi-transparent glass effects (`rgba(26, 34, 41, 0.6)`) with a high blur radius (20px+) for navigation bars and floating elements.
- **Overlays:** Subtle vignettes and dark-to-transparent gradients should be applied to images to ensure text legibility.
- **Interactions:** Elements should feel like they are floating on a single plane; use slight scale increases (1.02x) on hover instead of lifting with shadows.

## Shapes
The shape language is primarily **Pill-shaped** and organic. 

- **Interactive Elements:** Buttons and tags must use full pill-rounding to contrast against the sharp, architectural lines of the grid and the serif typography.
- **Containers:** Large image containers or sections may use `rounded-xl` (1.5rem) to soften the edges of the photography, making it feel more integrated into the "soft" brand personality.
- **Dividers:** When used, dividers should be thin (1px) and use low-opacity Misty Slate.

## Components
- **Primary Button:** Pill-shaped, Sand (`#F1E9DA`) background with Midnight (`#0D1117`) text. Includes a subtle icon (e.g., a list or arrow) to the right of the text.
- **Secondary/CTA Button:** Pill-shaped, Deep Ocean (`#1A2229`) background with white or light grey text. Used for less urgent actions like "Contact Me".
- **Navigation Toggle:** A circular ghost button with a thin border and three-line hamburger icon, positioned in the upper right.
- **Scroll Indicator:** A vertical line with "scroll" text in `label-sm`, positioned at the bottom center to encourage exploration.
- **Project Cards:** Full-width or half-width images with `rounded-xl` corners. Titles should appear as an overlay on hover or directly beneath in `headline-lg` serif.
- **Input Fields:** Bottom-border only (1px), using `title-md` for labels to keep the contact form feeling like a handwritten note rather than a technical form.